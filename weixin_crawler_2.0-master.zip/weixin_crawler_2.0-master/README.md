时间仓促，我们以后可能会推出更加详细的文档说明
weixin_crawler_2.0 实际上是在微搜的早期版本上修改而来
主要特点是运行简单

## USAGE
- install mongodb run with default setting port 27017
- install Elasticsearch 6 run with default setting
- pip3 install -r requirements.txt 安装项目依赖 遇到包找不到的错误 请单独安装
- python3 main.py run project

## ATTENTION
you should use Wechat 7.03 or lower
