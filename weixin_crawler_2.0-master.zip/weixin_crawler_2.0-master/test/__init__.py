"""
单元测试
"""

from cmp.protect import Passport

Passport.check_password()
